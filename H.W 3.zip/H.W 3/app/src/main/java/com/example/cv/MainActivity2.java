package com.example.cv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView z = findViewById(R.id.textView2);
        TextView s = findViewById(R.id.textView3);
        TextView r = findViewById(R.id.textView4);
        TextView u = findViewById(R.id.textView5);
        TextView o = findViewById(R.id.textView6);
        Bundle airport = getIntent().getExtras();
       String jude= airport.getString("n");
      String deema=   airport.getString("ag");
       String fahad=  airport.getString("j");
       String seba =  airport.getString("p");
       String majed =  airport.getString("em");
       z.setText(jude);
        s.setText(deema);
        r.setText(fahad);
        u.setText(seba);
        o.setText(majed);



    }
}