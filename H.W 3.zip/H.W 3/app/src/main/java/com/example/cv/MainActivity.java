package com.example.cv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText a = findViewById(R.id.editTextTextPersonName);
        final EditText b = findViewById(R.id.editTextTextPersonName2);
        final EditText c = findViewById(R.id.editTextTextPersonName3);
        final EditText d = findViewById(R.id.editTextTextPersonName4);
        final EditText e = findViewById(R.id.editTextTextPersonName5);
        Button next = findViewById(R.id.button);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = a.getText().toString();
                String age = b.getText().toString();
                String job = c.getText().toString();
                String phone =d.getText().toString();
                String email = e.getText().toString();
                Intent x = new Intent(MainActivity.this , MainActivity2.class);
                x.putExtra("n",name);
                x.putExtra("ag",age);
                x.putExtra("j",job);
                x.putExtra("p",phone);
                x.putExtra("em",email);



                startActivity(x);
            }
        });


    }
}